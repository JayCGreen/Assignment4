package com.example.spenderapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.security.Key;
import java.util.Collections;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    Button add, sub;
    EditText note, date, amt, desc;
    TextView bal;
    float money = 0;
    LinearLayout history;
    Context cont;

    String MyPREFERENCES = "p";
    String HistKey= "HistKey";
    String balanceKey = "Bkey";

    String entry = "";

    SharedPreferences sp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        add = findViewById(R.id.add);
        sub = findViewById(R.id.sub);
        date = findViewById(R.id.dateBlock);
        amt = findViewById(R.id.amountBlock);
        desc = findViewById(R.id.descBlock);
        history = findViewById(R.id.history);
        bal = findViewById(R.id.balance);


        sp = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        //SharedPreference sharedPref = cont.getSharedPreferences();
        money = sp.getFloat(balanceKey, (float) 0.00);
        bal.setText("$"+ money);
        note = new EditText(this);
        //set the balance


        Map all = sp.getAll();
        for (Object key: all.keySet()){
            if(key.toString().equals(balanceKey)){
                continue;
            }
            TextView x = new EditText(getBaseContext());
            x.setText(sp.getString(""+key, "not found"));
            history.addView(x, 0);
        }


        //history.addView(x, 0);





        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //create new instance of note view
                TextView n = new EditText(getBaseContext());
                //((ViewGroup)noteTest.getParent()).removeView(noteTest);
                entry = "Added $" + amt.getText().toString() + " on " + date.getText().toString() + " from " + desc.getText().toString();
                //add the amount to the balance here
                money += Float.parseFloat(amt.getText().toString());;
                bal.setText("$"+money);
                //reset the values and focus
                amt.setText(null);
                date.setText(null);
                desc.setText(null);
                date.requestFocus();

                //update shared prefs
                SharedPreferences.Editor editor = sp.edit();
                HistKey = HistKey.concat("" + Math.random()*200);
                editor.putFloat(balanceKey, money);
                editor.putString(HistKey, entry);
                editor.commit();
                n.setText(sp.getString(HistKey, entry));
                history.addView(n, 0);
            }
        });

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //create new instance of note view
                TextView n = new EditText(getBaseContext());
                //((ViewGroup)noteTest.getParent()).removeView(noteTest);
                entry = "Spent $" + amt.getText().toString() + " on " + date.getText().toString() + " for " + desc.getText().toString();
                //Subtract the amount to the balance here
                money -= Float.parseFloat(amt.getText().toString());;
                bal.setText("$"+money);
                //reset the values
                amt.setText(null);
                date.setText(null);
                desc.setText(null);
                date.requestFocus();

                //update prefs
                SharedPreferences.Editor editor = sp.edit();
                HistKey = HistKey.concat("" + Math.random()*200);
                editor.putFloat(balanceKey, money);
                editor.putString(HistKey, entry);
                editor.commit();
                n.setText(sp.getString(HistKey, entry));
                history.addView(n, 0);
            }
        });

    }


}
